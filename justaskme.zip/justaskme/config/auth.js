module.exports = {

    // 'facebookAuth' : {
    //     'clientID'      : 'your-secret-clientID-here', // your App ID
    //     'clientSecret'  : 'your-client-secret-here', // your App Secret
    //     'callbackURL'   : 'http://localhost:8080/auth/facebook/callback'
    // },

    // 'twitterAuth' : {
    //     'consumerKey'       : 'your-consumer-key-here',
    //     'consumerSecret'    : 'your-client-secret-here',
    //     'callbackURL'       : 'http://localhost:8080/auth/twitter/callback'
    // },

    'googleAuth' : {
        'clientID'      : '656047896892-6esjl8jme83a9vqc47dpj3b8rmcav9uf.apps.googleusercontent.com',
        'clientSecret'  : '8s9JCzqltwsHS_nowMhNnFAt',
        'callbackURL'   : 'http://localhost:3018/user'
    }

};